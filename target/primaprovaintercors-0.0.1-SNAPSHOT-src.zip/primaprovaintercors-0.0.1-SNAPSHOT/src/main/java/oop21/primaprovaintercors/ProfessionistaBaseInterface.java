package oop21.primaprovaintercors;

public interface ProfessionistaBaseInterface {
	void assistiCliente(Cliente cliente);
}
